package com.example;

import java.time.LocalDate;

public class Assignment {
    private final String id;
    private String role;
    private LocalDate startDate;

    private Colonist colonist;
    private HabitatModule habitatModule;

    public Assignment(String id, String role, LocalDate startDate, Colonist colonist, HabitatModule habitatModule) {
        this.id = id;
        this.role = role;
        this.startDate = startDate;
        setColonist(colonist);
        setHabitatModule(habitatModule);
    }

    public String getId() {
        return id;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public LocalDate getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDate startDate) {
        this.startDate = startDate;
    }

    public Colonist getColonist() {
        return colonist;
    }

    public void setColonist(Colonist colonist) {
        if (this.colonist != null) {
            this.colonist.removeAssignment(this);
        }
        this.colonist = colonist;
        if (colonist != null && !colonist.getAssignments().contains(this)) {
            colonist.addAssignment(this);
        }
    }

    public HabitatModule getHabitatModule() {
        return habitatModule;
    }

    public void setHabitatModule(HabitatModule habitatModule) {
        if (this.habitatModule != null) {
            this.habitatModule.removeAssignment(this);
        }
        this.habitatModule = habitatModule;
        if (habitatModule != null && !habitatModule.getAssignments().contains(this)) {
            habitatModule.addAssignment(this);
        }
    }
}
