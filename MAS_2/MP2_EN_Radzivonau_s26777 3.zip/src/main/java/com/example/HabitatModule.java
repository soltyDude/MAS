package com.example;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class HabitatModule {
    private final String id;
    private String type;
    private String status;

    // Множество назначений в модуле
    private final Set<Assignment> assignments = new HashSet<>();

    // Множество хранилищ ресурсов (композиция)
    private final Set<ResourceStorage> resourceStorages = new HashSet<>();

    public HabitatModule(String id, String type, String status) {
        this.id = id;
        this.type = type;
        this.status = status;
    }

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Методы для управления назначениями
    public void addAssignment(Assignment assignment) {
        if (assignment == null) return;
        if (assignments.add(assignment)) {
            assignment.setHabitatModule(this);
        }
    }

    public void removeAssignment(Assignment assignment) {
        if (assignment == null) return;
        if (assignments.remove(assignment)) {
            assignment.setHabitatModule(null);
        }
    }

    public Set<Assignment> getAssignments() {
        return Collections.unmodifiableSet(assignments);
    }

    // Методы для управления хранилищами ресурсов
    public void addResourceStorage(ResourceStorage storage) {
        if (storage == null) return;
        if (resourceStorages.add(storage)) {
            storage.setHabitatModule(this);
        }
    }

    public void removeResourceStorage(ResourceStorage storage) {
        if (storage == null) return;
        if (resourceStorages.remove(storage)) {
            storage.setHabitatModule(null);
        }
    }

    public Set<ResourceStorage> getResourceStorages() {
        return Collections.unmodifiableSet(resourceStorages);
    }
}
