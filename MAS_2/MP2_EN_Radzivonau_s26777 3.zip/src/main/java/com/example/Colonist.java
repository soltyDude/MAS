package com.example;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Colonist {
    private final String id;
    private String name;
    private String rank;

    // Множество задач, назначенных колонисту
    private final Set<Task> tasks = new HashSet<>();

    // Множество назначений колониста
    private final Set<Assignment> assignments = new HashSet<>();

    public Colonist(String id, String name, String rank) {
        this.id = id;
        this.name = name;
        this.rank = rank;
    }

    // Геттеры и сеттеры для name и rank
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getId() {
        return id;
    }

    // Методы для управления задачами
    public void addTask(Task task) {
        if (task == null) return;
        if (tasks.add(task)) {
            task.setColonist(this);
        }
    }

    public void removeTask(Task task) {
        if (task == null) return;
        if (tasks.remove(task)) {
            task.setColonist(null);
        }
    }

    public Set<Task> getTasks() {
        return Collections.unmodifiableSet(tasks);
    }

    // Методы для управления назначениями
    public void addAssignment(Assignment assignment) {
        if (assignment == null) return;
        if (assignments.add(assignment)) {
            assignment.setColonist(this);
        }
    }

    public void removeAssignment(Assignment assignment) {
        if (assignment == null) return;
        if (assignments.remove(assignment)) {
            assignment.setColonist(null);
        }
    }

    public Set<Assignment> getAssignments() {
        return Collections.unmodifiableSet(assignments);
    }
}
