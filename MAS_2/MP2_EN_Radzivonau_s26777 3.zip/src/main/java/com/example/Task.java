package com.example;

public class Task {
    private final String id;
    private String description;
    private String status;

    // Колонист, которому назначена задача
    private Colonist colonist;

    public Task(String id, String description, String status) {
        this.id = id;
        this.description = description;
        this.status = status;
    }

    // Геттеры и сеттеры
    public String getId() {
        return id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Colonist getColonist() {
        return colonist;
    }

    public void setColonist(Colonist colonist) {
        // Удаляем из предыдущего колониста
        if (this.colonist != null) {
            this.colonist.removeTask(this);
        }
        this.colonist = colonist;
        // Добавляем к новому колонисту
        if (colonist != null && !colonist.getTasks().contains(this)) {
            colonist.addTask(this);
        }
    }
}
