package com.colony.mas_5.repository;

import com.colony.mas_5.entity.Colonist;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ColonistRepository extends JpaRepository<Colonist, Long> {
}
