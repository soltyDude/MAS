package com.example;

public enum ResourceType {
    WATER, OXYGEN, FUEL
}
